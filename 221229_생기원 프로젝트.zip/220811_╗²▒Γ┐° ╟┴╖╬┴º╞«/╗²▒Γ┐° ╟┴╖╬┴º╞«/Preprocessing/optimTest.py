from scipy import optimize

def f(x):
    return (x-1)**2

minimum = optimize.fmin(f, 1)
print(minimum)