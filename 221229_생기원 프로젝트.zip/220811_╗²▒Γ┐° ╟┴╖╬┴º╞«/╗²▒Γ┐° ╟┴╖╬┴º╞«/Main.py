from nbformat import read
from SimulationEngine.SimulationEngine import SimulationEngine
from SimulationEngine.Utility.Configurator import Configurator
from Coupled.Outmost import Outmost
import json
import numpy as np
import csv
from scipy.optimize import minimize
from scipy import optimize
import os


def function(k):

    file_path = "./Output.csv"

    if os.path.exists(file_path):
        os.remove(file_path)

    script_path = os.path.dirname(__file__)
    filename = os.path.join(script_path, 'input.json')

    with open(filename) as f:
        json_data = json.load(f)
        f.close()
    print(json.dumps(json_data))


    objConfiguration = Configurator()
    objConfiguration.addConfiguration('heatTemp',float(json_data['Billet']['heatTemp']))
    objConfiguration.addConfiguration('coolTemp',float(json_data['Billet']['coolTemp']))
    objConfiguration.addConfiguration('curTemp_1',float(json_data['Billet']['curTemp_1']))
    objConfiguration.addConfiguration('curTemp_2',float(json_data['Billet']['curTemp_2']))
    objConfiguration.addConfiguration('curTemp_3',float(json_data['Billet']['curTemp_3']))
    objConfiguration.addConfiguration('k1',k[0])
    objConfiguration.addConfiguration('k2',k[1])
    objConfiguration.addConfiguration('k3',k[2])

    objModels = Outmost(objConfiguration)
    engine = SimulationEngine()
    engine.setOutmostModel(objModels)

    engine.run(maxTime=5000, \
            logFileName='log.txt', \
            visualizer=False, \
            logGeneral=False, \
            logActivateState=True, \
            logActivateMessage=False, \
            logActivateTA=True, \
            logStructure=False \
            )
    #값가져와서 오차계산
    with open('Output.csv', newline='') as f:
        reader = csv.reader(f)
        data = list(reader)
        f.close()
    #오차 리턴
    ret, ret_ = [],[]

    for i in range(len(data[0])):
        ret.append(float(data[1][i])-float(data[1][i]))
    ret_ = sum(ret)

    return  ret_# sigma(시뮬레이션 결과값 - 실제데이터 값)

if __name__ == '__main__':
    init = np.array([0.03, 0.9, -0.5])
    minimum = optimize.fmin(function, init, args=(), xtol=0.001, ftol=0.001, maxiter=None, maxfun=None, full_output=0, disp=1, retall=0, callback=None)
    print(minimum)
