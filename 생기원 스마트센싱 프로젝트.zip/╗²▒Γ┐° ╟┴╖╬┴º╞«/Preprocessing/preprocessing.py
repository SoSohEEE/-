import os
import csv
import numpy as np
import pandas as pd

if os.path.exists('./Preprocessing/(전처리)환경온도에 따른 상온냉각특성'):
    pass
else:
    os.mkdir('./Preprocessing/(전처리)환경온도에 따른 상온냉각특성')

# 환경온도별 폴더생성
for i in range(6):
    dir_path = f"./Preprocessing/(전처리)환경온도에 따른 상온냉각특성/{15+5*i}도"
    if os.path.exists(dir_path):
        continue
    else:
        os.mkdir(dir_path)

time = []
cur_1 = []
cur_2 = []
cur_3 = []


topFolder = os.listdir('./Preprocessing/환경온도에 따른 (상온,가열)냉각특성')

def preprocessing(t,m):
    data = []
    j = 0
    row = 0
    curTime = 0
    preTime = 0
    
    f_mid = './Preprocessing/환경온도에 따른 (상온,가열)냉각특성/'+str(topFolder[t])
    
    midFolder = os.listdir(f_mid)

    f = open('./Preprocessing/환경온도에 따른 (상온,가열)냉각특성/'+topFolder[t]+'/'+midFolder[m],'r')
    rdr = csv.reader(f)

    for line in rdr:

        if row > 5:

            temp = float(line[0])
            curTime = int(temp)
            if curTime != preTime:
                line[0] = curTime
                data.append(line)
                #print(line)

            preTime = curTime

        row += 1

    f.close()
    
    df = pd.DataFrame(data)
    df = df.replace('', -999, regex=True)
    df[[1,2,3,4,5]] = df[[1,2,3,4,5]].astype(float)

    data = [df[0].tolist(), df[1].tolist(), df[2].tolist(), df[3].tolist(), df[4].tolist(), df[5].tolist()]
    preprocessList = [[] for i in range(6)]

    while(1):
        if data[3][j] > 200.0:
            break
        j+=1

    for i in range(5):
        if j >= 1:
            preprocessList[i+1] = data[i+1][j-1:]
        else:
            preprocessList[i+1] = data[i+1][j:]

    preprocessList[0] = list(range(1, len(preprocessList[1]) + 1))

    preprocessDf = pd.DataFrame(preprocessList)
    preprocessDf = preprocessDf.transpose()
    preprocessDf = preprocessDf.replace(-999, np.nan, regex=True)
    preprocessDf[0] = preprocessDf[0].astype(int)
    preprocessDf.columns = ['시간','가열온도1','가열온도2','가열온도3','쿨링온도','환경온도']
    
    preprocessDf.to_csv(f'./Preprocessing/(전처리)환경온도에 따른 상온냉각특성/{15+5*t}도/'+midFolder[m],sep=',', index = False)
    


# 상온
for i in range(6):
    for j in  range(5):  
        preprocessing(i,j)