from SimulationEngine.ClassicDEVS.DEVSCoupledModel import DEVSCoupledModel
from SimulationEngine.ClassicDEVS.DEVSAtomicModel import DEVSAtomicModel
from Atomic.billet import Billet

class Outmost(DEVSCoupledModel):
    def __init__(self, objConfiguration):
        super().__init__("billetSim")

        self.objConfiguration = objConfiguration
 
        self.billet = Billet(self.objConfiguration)
        self.addModel(self.billet)

        pass
    