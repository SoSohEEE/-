from nbformat import read
from SimulationEngine.SimulationEngine import SimulationEngine
from SimulationEngine.Utility.Configurator import Configurator
from Coupled.Outmost import Outmost
import json
import numpy as np
import csv
from scipy.optimize import minimize
from scipy import optimize
import os
import matplotlib.pyplot as plt
import math

k1 = []
k2 = []
k3 = []

def function(k):
    file_path = "./Data/Output.csv"

    if os.path.exists(file_path):
        os.remove(file_path)

    with open('./Data/input.json', 'r') as f:
        json_data = json.load(f)
        f.close()
    print(json.dumps(json_data) )

    objConfiguration = Configurator()
    objConfiguration.addConfiguration('heatTemp',float(json_data['Billet']['heatTemp']))
    objConfiguration.addConfiguration('coolTemp',float(json_data['Billet']['coolTemp']))
    objConfiguration.addConfiguration('curTemp_1',float(json_data['Billet']['curTemp_1']))
    objConfiguration.addConfiguration('curTemp_2',float(json_data['Billet']['curTemp_2']))
    objConfiguration.addConfiguration('curTemp_3',float(json_data['Billet']['curTemp_3']))
    objConfiguration.addConfiguration('inflectionTime', int(json_data['Billet']['inflectionTime']))
    objConfiguration.addConfiguration('finishTime', int(json_data['Billet']['finishTime']))
    objConfiguration.addConfiguration('k1',k[0])
    objConfiguration.addConfiguration('k2',k[1])
    objConfiguration.addConfiguration('k3',k[2])

    objModels = Outmost(objConfiguration)
    engine = SimulationEngine()
    engine.setOutmostModel(objModels)

    engine.run(maxTime=50000, \
            logFileName='log.txt', \
            visualizer=False, \
            logGeneral=False, \
            logActivateState=True, \
            logActivateMessage=False, \
            logActivateTA=True, \
            logStructure=False \
            )
 
    with open('./Data/Output.csv', newline='') as f:
        reader = csv.reader(f)
        data = list(reader)
        f.close()

    ret, ret_ = [],[]
    index = 0

    for i in newData:
        if i == None:
            data[2][index] = float(data[2][index])
        else:
            if index < len(data[2]):
                data[2][index] = float(data[2][index])
                ret.append(abs(math.sqrt(math.pow(i-data[2][index],2))))
                index += 1

    plt.plot(newData,'b', marker ='*')
    plt.plot(data[2][0:-50],'r--', marker ='*')
    # plt.grid(True)
    plt.pause(0.01)
    plt.cla()

    ret_ = sum(ret)
    k1.append(k[0])
    k2.append(k[1])
    k3.append(k[2])


    return  ret_# sigma(시뮬레이션 결과값 - 실제데이터 값)


if __name__ == '__main__':
    
    file_path = "./Data/ref_data_train.csv"
    with open(file_path, newline='') as f:
        reader = csv.reader(f)
        data = list(reader)
        f.close()
    newData = []
    
    for i in data:
        if i[0] != '0':
            newData.append(float(i[0]))
        elif i[0] == '0':
            newData.append(None)

    init = np.array([0, 0.0, 0])
    # bound =((1.2, 1.3), (0.8, 1.0), (-0.4, -0.10))
    # bound =((1.1, 1.6), (0.9, 1.1), (-0.15, 0.10))40 bound
    bound =((0.9, 1.5), (0.9, 1.5), (-5, 1.5))
    minimum = optimize.minimize(function, init, args=(), method=None, 
                                jac=None, hess=None, hessp=None, 
                                bounds=bound, constraints=(), 
                                tol=0.0001, callback=None, options=None)
    print(minimum)
    with open('./Data/kList.csv','w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(k1)
        writer.writerow(k2)
        writer.writerow(k3)
        f.close()
    plt.show()
