
import math
import numpy as np
import time
import select
import threading
import socket
import select
import json

class NetAdapter:
    def __init__(self):
        self.queueSendEvent = []
        self.queueRecvEvent = []
        self.sock = None
        pass

    def openClient(self):

        #소켓 연결
        serverConnect = False
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        while serverConnect ==False:
            try:
                self.sock.connect(('127.0.0.1', 3500))  # 서버에 접속
                serverConnect = True

                threadRecv = threading.Thread(target=self.receiveEvent, args=())# 쓰레드 생성
                threadRecv.start()
            except  Exception as e:
                print('Wait ....')
                time.sleep(1)
                pass
        pass
    
    def openServer(self):
            #######
            self.HOST = '127.0.0.1'
            self.PORT = 3500        

            self.serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.serverSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.serverSocket.bind((self.HOST, self.PORT))

            self.serverSocket.listen()
            self.sock, self.addr = self.serverSocket.accept()

            print('Connected by', self.addr)

            threadRecv = threading.Thread(target=self.receiveEvent, args=())
            threadRecv.start()
            pass

    def sendToEvent(self, event, speed):
        output = self.toJson(event)
        output = bytes(output.encode())
        self.sock.send(output)
        time.sleep(1/speed)
        pass
    
    def getRecvMessage(self):
        if len(self.queueRecvEvent) == 0:
            return None
        else : 
            return self.queueRecvEvent


    def clearRecvMessage(self):
        self.queueRecvEvent.clear()

    def setRecvMessage(self):
        self.queueRecvEvent.clear()


    def receiveEvent(self):
        while True:
            read, write, fail = select.select((self.sock, ), (), ())
            for dsec in read:
                recvData = self.sock.recv(1024)
                event = self.byte2json(recvData)
                self.queueRecvEvent.append(event)

    def byte2json(self,data):
        try:
            data = json.loads(data)
            return data
        except:
            print('setReceiveEvent error')

    