from time import time

from nbformat import write
from SimulationEngine.ClassicDEVS.DEVSAtomicModel import DEVSAtomicModel
import time
import numpy as np
import matplotlib.pyplot as plt
import csv


class Billet(DEVSAtomicModel):
    def __init__(self, objConfiguration):
        super().__init__('Billet')
        self.status = ['DATA_LOAD','HEATING', 'COOLING', 'FINISH']
        self.addStateVariable("status", self.status[0])
        self.objConfiguration = objConfiguration
        self.heatTemp = self.objConfiguration.getConfiguration('heatTemp')
        self.coolTemp = self.objConfiguration.getConfiguration('coolTemp')
        self.curTemp_1 = self.objConfiguration.getConfiguration('curTemp_1')
        self.curTemp_2 = self.objConfiguration.getConfiguration('curTemp_2')
        self.curTemp_3 = self.objConfiguration.getConfiguration('curTemp_3')
        self.finishTime = self.objConfiguration.getConfiguration('finishTime')
        self.inflectionTime = self.objConfiguration.getConfiguration('inflectionTime')

        self.lstTemperature_1 = []
        self.lstTemperature_2 = []
        self.lstTemperature_3 = []

        self.k1 = self.objConfiguration.getConfiguration('k1')
        self.k2 = self.objConfiguration.getConfiguration('k2')
        self.k3 = self.objConfiguration.getConfiguration('k3')

    def funcExternalTransition(self, strPort, objEvent):
        return True

    def funcOutput(self):
        if self.getStateValue('status') == 'HEATING':
            # print('Time : '+str(self.getTime()) + ', current Temperature : ' + str(self.curTemp_1))
            self.lstTemperature_1.append(self.curTemp_1)
            self.lstTemperature_2.append(self.curTemp_2)
            self.lstTemperature_3.append(self.curTemp_3)
            pass
        elif self.getStateValue('status') == 'COOLING':
            # print('Time : '+str(self.getTime()) + ', current Temperature : ' + str(self.curTemp_1))
            self.lstTemperature_1.append(self.curTemp_1)
            self.lstTemperature_2.append(self.curTemp_2)
            self.lstTemperature_3.append(self.curTemp_3)
            pass
        elif self.getStateValue('status') == 'FINISH':
            pass

        with open('./data/Output.csv','w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(self.lstTemperature_1)
            writer.writerow(self.lstTemperature_2)
            writer.writerow(self.lstTemperature_3)
            f.close()
        return True 
    
    def funcInternalTransition(self):
        if self.getStateValue('status') == 'DATA_LOAD' and self.getTime() == 0:
  
            #상태변경
            self.setStateValue('status', self.status[1])
            pass
        elif self.getStateValue('status') == 'HEATING' : #가열온도 예측
            #예측 모델
            self.curTemp_1 = self.curTemp_1 + 1*self.k1
            self.curTemp_2 = self.curTemp_2 + 1*self.k1
            self.curTemp_3 = self.curTemp_3 + 1*self.k1

            avgTemp = (self.curTemp_3+self.curTemp_2+self.curTemp_1)/3

            if self.getTime() >= self.inflectionTime:
                self.setStateValue('status', self.status[2])
                # print('state transition ' + 'HEATING' + '->' + str(self.getStateValue('status')))

        elif self.getStateValue('status') == 'COOLING': #냉각온도 예측
            #임시 코드
            # if self.getTime() == 177:
            #     self.curTemp_1 = 403
            #     self.curTemp_2 = 403
            #     self.curTemp_3 = 403

            #예측 모델

            self.curTemp_1 = self.k2*1*self.curTemp_1+self.k3
            self.curTemp_2 = self.k2*1*self.curTemp_2+self.k3
            self.curTemp_3 = self.k2*1*self.curTemp_3+self.k3

            avgTemp = (self.curTemp_3+self.curTemp_2+self.curTemp_1)/3

                
            if self.getTime() >= self.finishTime or avgTemp>100000:
                self.setStateValue('status', self.status[3])
                # print('state transition ' + 'COOLING' + '->' + str(self.getStateValue('status')))
     
        elif self.getStateValue('status') == 'FINISH':
            pass
        return True

    def funcTimeAdvance(self):
        if self.getStateValue('status') == 'HEATING' or self.getStateValue('status') == 'COOLING':
            return 1
        elif self.getStateValue('status')=='DATA_LOAD':
            return 0
        else:
            return 999999999999
    def funcSelect(self):
        pass

    pass