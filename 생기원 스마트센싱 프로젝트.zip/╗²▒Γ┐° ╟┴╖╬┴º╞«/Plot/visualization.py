from turtle import color
from nbformat import read
import json
import numpy as np
import csv
from scipy.optimize import minimize
from scipy import optimize
import os
import numpy as np
import matplotlib.pyplot as plt

mainLoot = './Preprocessing/(전처리)환경온도에 따른 상온냉각특성'
topFolder = os.listdir(mainLoot)

data = []
total = []
j = 0

curTime = 0
preTime = 0

for i in topFolder:
    f_mid = mainLoot+'/'+str(i)
    midFolder = os.listdir(f_mid)
    for j in midFolder:
        f = open(mainLoot+'/'+i+'/'+j, encoding='utf-8')
        rdr = csv.reader(f)
        row = 0
        data = []
        for line in rdr:
            if row > 0:
                temp = float(line[0])
                curTime = int(temp)
                if curTime != preTime:
                    line[0] = curTime
                    data.append(line)
                preTime = curTime
            row += 1
        total.append([data])
            


    pass