from turtle import color
from nbformat import read
from SimulationEngine.SimulationEngine import SimulationEngine
from SimulationEngine.Utility.Configurator import Configurator
from Coupled.Outmost import Outmost
import json
import numpy as np
import csv
from scipy.optimize import minimize
from scipy import optimize
import os
import numpy as np
import matplotlib.pyplot as plt


with open('./data/kList.csv', newline='') as f:
    reader = csv.reader(f)
    data = list(reader)
    f.close()

for i in range(len(data[0])):
    data[0][i] = float(data[0][i])
    data[1][i] = float(data[1][i])
    data[2][i] = float(data[2][i])  
plt.grid(True)
plt.plot(data[0],'ro--',marker='*')
plt.figure()
plt.grid(True)
plt.plot(data[1],'gs--',marker='^')
plt.figure()
plt.grid(True)
plt.plot(data[2],'bs--',)
plt.grid(True)

plt.show()