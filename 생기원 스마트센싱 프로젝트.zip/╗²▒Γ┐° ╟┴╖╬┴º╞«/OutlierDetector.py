import Module.NetAdapter as NetAdapter
import csv
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from pyqtgraph import PlotWidget
from PyQt5.QtWidgets import QFileDialog
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def __init__(self):
        self.curTime = 0 
        self.isConnect = 0
        self.filePath = None
        self.simData = []
        self.y2 = []
        self.y = []
        self.x = []
        pass

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1200, 700)
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        MainWindow.setFixedSize(QSize(1200, 700))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.btnConnection = QtWidgets.QPushButton(self.centralwidget)
        self.btnConnection.setGeometry(QtCore.QRect(1100, 40, 71, 51))
        self.btnConnection.setObjectName("pushButton")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(20, 530, 1151, 91))
        self.textEdit.setObjectName("textEdit")
        self.lblSystemLog = QtWidgets.QLabel(self.centralwidget)
        self.lblSystemLog.setGeometry(QtCore.QRect(20, 480, 91, 71))
        self.lblSystemLog.setMaximumSize(QtCore.QSize(91, 16777215))
        self.lblSystemLog.setTextFormat(QtCore.Qt.AutoText)
        self.lblSystemLog.setObjectName("label")
        self.lblIsConnection = QtWidgets.QLabel(self.centralwidget)
        self.lblIsConnection.setGeometry(QtCore.QRect(20, -20, 91, 71))
        self.lblIsConnection.setMaximumSize(QtCore.QSize(91, 16777215))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setBold(False)
        font.setWeight(50)
        self.lblIsConnection.setFont(font)
        self.lblIsConnection.setTextFormat(QtCore.Qt.AutoText)
        self.lblIsConnection.setObjectName("label_2")
        self.lineSetIP = QtWidgets.QLineEdit(self.centralwidget)
        self.lineSetIP.setGeometry(QtCore.QRect(60, 50, 191, 31))
        self.lineSetIP.setObjectName("lineEdit")
        self.lblIP = QtWidgets.QLabel(self.centralwidget)
        self.lblIP.setGeometry(QtCore.QRect(20, 30, 91, 71))
        self.lblIP.setMaximumSize(QtCore.QSize(91, 16777215))
        self.lblIP.setTextFormat(QtCore.Qt.AutoText)
        self.lblIP.setObjectName("label_3")
        self.lblPort = QtWidgets.QLabel(self.centralwidget)
        self.lblPort.setGeometry(QtCore.QRect(20, 80, 91, 71))
        self.lblPort.setMaximumSize(QtCore.QSize(91, 16777215))
        self.lblPort.setTextFormat(QtCore.Qt.AutoText)
        self.lblPort.setObjectName("label_4")
        self.lineSetPort = QtWidgets.QLineEdit(self.centralwidget)
        self.lineSetPort.setGeometry(QtCore.QRect(60, 100, 191, 31))
        self.lineSetPort.setObjectName("lineEdit_2")
        self.lblPlot = QtWidgets.QLabel(self.centralwidget)
        self.lblPlot.setGeometry(QtCore.QRect(20, 120, 91, 71))
        self.lblPlot.setMaximumSize(QtCore.QSize(91, 16777215))
        self.lblPlot.setTextFormat(QtCore.Qt.AutoText)
        self.lblPlot.setObjectName("label_5")
        self.btnDisconnection = QtWidgets.QPushButton(self.centralwidget)
        self.btnDisconnection.setGeometry(QtCore.QRect(1100, 100, 71, 51))
        self.btnDisconnection.setObjectName("pushButton_2")
        self.PlotWidget = PlotWidget(self.centralwidget)
        self.PlotWidget.setGeometry(QtCore.QRect(20, 170, 1151, 321))
        self.PlotWidget.setObjectName("PlotWidget")
        self.btnSimulation = QtWidgets.QPushButton(self.centralwidget)
        self.btnSimulation.setGeometry(QtCore.QRect(920, 40, 180, 51))
        self.btnSimulation.setObjectName("pushButton_5")
        self.btnFileLoad = QtWidgets.QPushButton(self.centralwidget)
        self.btnFileLoad.setGeometry(QtCore.QRect(920, 100, 180, 51))
        self.btnFileLoad.setObjectName("pushButton_6")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1200, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.btnConnection.clicked.connect(self.btnConnect)
        self.btnFileLoad.clicked.connect(self.loadFile)

    def btnConnect(self):
        self.isConnect ^= 1
        print(self.isConnect)
        self.server = NetAdapter.NetAdapter()
        self.server.openServer()
        self.textEdit.setText('연결되었습니다.')
        self.timer = QTimer()                   # timer 변수에 QTimer 할당
        self.timer.start(100)                  # 10000msec(10sec) 마다 반복
        self.timer.timeout.connect(self.rcvData)    # start time out시 연결할 함수
        pass

    def loadFile(self):
        with open('./Data/Output.csv', newline='') as f:
            reader = csv.reader(f)
            data = list(reader)
            f.close()

        for i in data[0]:
            self.simData.append(float(i))
        self.textEdit.append('데이터 셋팅이 완료되었습니다.')

    def rcvData(self):
        msg = self.server.getRecvMessage()
        try:
            if len(msg) != 0:
                ret = float(msg[0]) - self.simData[self.curTime]
                prt = 'curTime: ' + str(self.curTime) +', Error : ' + str(ret)

                self.x.append(self.curTime)
                self.y.append(msg[0])
                self.y2.append(self.simData[self.curTime])
                self.PlotWidget.plot(self.x,self.y, title='Sim', name='Legend name', pen='g', symbol='o', symbolPen='g', symbolBrush=0.2)
                self.PlotWidget.plot(self.x,self.y2, title='Real', name='Legend name', pen='r', symbol='x', symbolPen='r', symbolBrush=0.2)
                self.PlotWidget.showGrid(x=True, y=True) #그리드 표현
                self.PlotWidget.setTitle(title='Temperature')

                self.textEdit.append(prt)
                msg = None
                self.server.clearRecvMessage()
                self.curTime += 1
        except:
            pass

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.btnConnection.setText(_translate("MainWindow", "연결"))
        self.lblSystemLog.setText(_translate("MainWindow", "System log"))
        self.lblIsConnection.setText(_translate("MainWindow", "통신연결"))
        self.lineSetIP.setText(_translate("MainWindow", "127.0.0.1"))
        self.lblIP.setText(_translate("MainWindow", "IP"))
        self.lblPort.setText(_translate("MainWindow", "Port"))
        self.lineSetPort.setText(_translate("MainWindow", "3500"))
        self.lblPlot.setText(_translate("MainWindow", "Plot"))
        self.btnDisconnection.setText(_translate("MainWindow", "해제"))
        self.btnSimulation.setText(_translate("MainWindow", "예측결과 시뮬레이션"))
        self.btnFileLoad.setText(_translate("MainWindow", "예측결과 불러오기"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())


